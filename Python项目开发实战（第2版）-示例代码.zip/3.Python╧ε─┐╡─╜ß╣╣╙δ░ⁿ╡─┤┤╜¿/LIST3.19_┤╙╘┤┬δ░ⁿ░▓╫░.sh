$ pip install ./logfilter-0.9.2
