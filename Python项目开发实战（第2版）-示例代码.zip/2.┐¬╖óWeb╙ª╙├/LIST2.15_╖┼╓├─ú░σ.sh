$ mkdir templates
$ mv index.html templates/
