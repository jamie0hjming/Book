$ sudo mkdir /var/www
$ sudo chown www-data:www-data /var/www
