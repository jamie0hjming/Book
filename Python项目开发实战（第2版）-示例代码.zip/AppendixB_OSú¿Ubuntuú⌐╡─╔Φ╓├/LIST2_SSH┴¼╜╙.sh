$ ssh -p 2222 bpbook@127.0.0.1
The authenticity of host '[127.0.0.1]:2222 ([127.0.0.1]:2222)' can't be established.
RSA key fingerprint is d0:e8:9f:96:8e:24:0d:96:dc:0b:51:fb:7f:b7:1b:f0.
Are you sure you want to continue connecting (yes/no)? yes
Warning: Permanently added '[127.0.0.1]:2222' (RSA) to the list of known hosts.
bpbook@127.0.0.1's password:
