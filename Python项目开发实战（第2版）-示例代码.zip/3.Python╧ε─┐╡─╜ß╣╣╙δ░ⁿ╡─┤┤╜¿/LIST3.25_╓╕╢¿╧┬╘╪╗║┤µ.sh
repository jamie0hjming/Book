$ pip install --download-cache=~/.pip-cache requests
