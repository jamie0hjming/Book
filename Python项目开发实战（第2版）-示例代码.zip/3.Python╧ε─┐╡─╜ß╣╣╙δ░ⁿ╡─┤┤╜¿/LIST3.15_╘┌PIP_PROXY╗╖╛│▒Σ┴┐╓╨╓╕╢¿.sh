$ export PIP_PROXY=proxy.example.com:1234
$ pip install requests
