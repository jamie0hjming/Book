$ sudo pip install virtualenv
-（中间省略）-
Successfully installed virtualenv
Cleaning up...
