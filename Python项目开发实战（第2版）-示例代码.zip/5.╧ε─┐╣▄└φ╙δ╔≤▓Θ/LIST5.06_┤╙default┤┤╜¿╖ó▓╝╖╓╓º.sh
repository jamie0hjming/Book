$ hg update default
$ hg branch m1231
