FIXTURE_DIRS = [
    os.path.join(BASE_DIR, 'fixtures'),
]
