(.venv)$ virtualenv --clear .venv  # 删除.venv环境内的全部依赖库
(.venv)$ pip install -e .          # 根据./setup.py安装依赖库
