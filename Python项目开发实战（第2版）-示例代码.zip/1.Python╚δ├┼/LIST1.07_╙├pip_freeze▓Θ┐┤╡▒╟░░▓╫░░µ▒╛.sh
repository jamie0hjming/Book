$ pip freeze
PAM==0.4.2
Twisted-Core==13.2.0
apt-xapian-index==0.45
argparse==1.2.1
configobj==4.7.2
：
：
