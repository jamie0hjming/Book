$ hg resolve -l
U conflict.txt
