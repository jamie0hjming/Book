$ sudo pip install mercurial
$ sudo service apache2 restart
