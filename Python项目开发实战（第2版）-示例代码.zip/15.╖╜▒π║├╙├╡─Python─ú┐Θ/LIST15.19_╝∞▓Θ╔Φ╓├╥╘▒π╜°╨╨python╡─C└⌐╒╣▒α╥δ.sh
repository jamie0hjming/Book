$ pkg-config python-2.7 --libs --cflags
-I/usr/include/python2.7 -I/usr/include/x86_64-linux-gnu/python2.7  -lpython2.7
