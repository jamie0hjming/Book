$ hg clone ssh://example.com//var/hg/testrepo
