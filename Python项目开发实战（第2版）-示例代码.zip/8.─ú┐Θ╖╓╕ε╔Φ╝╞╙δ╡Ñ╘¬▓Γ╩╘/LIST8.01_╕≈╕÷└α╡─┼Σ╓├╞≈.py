class TestIt(unittest.TestCase):

    def setUp(self):
        """ 搭建测试环境 """

    def tearDown(self):
        """ 测试后的环境清理 """
