   :
   :

def main():
    application.run('127.0.0.1', 8000)

if __name__ == '__main__':
    # 在IP地址127.0.0.1的8000端口运行应用程序
    application.run('127.0.0.1', 8000, debug=True)
