 def add(x, y):
     return x + y

 x = 0
 import pdb; pdb.set_trace()
 x = add(1, 2)
