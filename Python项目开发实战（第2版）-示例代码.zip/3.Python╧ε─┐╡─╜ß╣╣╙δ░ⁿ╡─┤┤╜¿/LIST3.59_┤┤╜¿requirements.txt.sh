(.venv)$ pip freeze > requirements.txt
