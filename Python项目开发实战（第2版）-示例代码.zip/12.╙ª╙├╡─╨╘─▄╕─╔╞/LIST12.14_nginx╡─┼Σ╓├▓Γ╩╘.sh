$ sudo nginx -t
