$ cd ..
$ virtualenv .venv
