(.venv)$ pip install -e ./guestbook
-（中间省略）-
Successfully installed guestbook
Cleaning up...

(.venv)$ ls .venv/bin/guestbook
guestbook

(.venv)$ guestbook
 * Running on http://127.0.0.1:8000/
 * Restarting with reloader
