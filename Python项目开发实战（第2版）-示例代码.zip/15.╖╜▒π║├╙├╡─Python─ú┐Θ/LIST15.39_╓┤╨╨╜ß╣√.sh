$ python tweepy_hello.py
bpbook: 测试。
liblar_jp: 【有关添加功能的通知】书籍相关
connpass_jp: 【有关功能修改的通知】多天以来
liblar_jp: 【有关维护工作已全面结束的通知】
beproud_jp: BeProud公司现在就Web
（以下省略）
