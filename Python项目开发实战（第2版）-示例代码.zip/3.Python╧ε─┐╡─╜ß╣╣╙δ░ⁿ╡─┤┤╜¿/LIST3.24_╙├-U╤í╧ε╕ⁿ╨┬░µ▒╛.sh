$ pip install -U requests
