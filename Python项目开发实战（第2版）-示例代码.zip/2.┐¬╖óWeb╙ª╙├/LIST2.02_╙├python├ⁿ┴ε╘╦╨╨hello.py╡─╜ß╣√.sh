$ python hello.py
200 OK
Content-Type: text/plain

Hello CGI!
