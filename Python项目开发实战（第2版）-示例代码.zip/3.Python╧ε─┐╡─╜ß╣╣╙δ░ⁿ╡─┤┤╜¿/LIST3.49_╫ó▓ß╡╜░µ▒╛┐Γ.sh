$ cd ~/guestbook
$ hg init
$ hg add LICENSE.txt MANIFEST.in guestbook setup.py
$ hg ci -m "initial"
