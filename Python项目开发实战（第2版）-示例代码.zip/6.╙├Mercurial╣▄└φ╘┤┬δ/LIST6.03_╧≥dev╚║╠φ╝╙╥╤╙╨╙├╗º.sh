$ sudo usermod -a -G dev <username>
