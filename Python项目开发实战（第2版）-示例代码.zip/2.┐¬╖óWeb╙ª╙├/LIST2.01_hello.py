#!/usr/bin/env python
print "200 OK"
print "Content-Type: text/plain"
print ""
print "Hello CGI!"
