$ sudo service nginx reload
