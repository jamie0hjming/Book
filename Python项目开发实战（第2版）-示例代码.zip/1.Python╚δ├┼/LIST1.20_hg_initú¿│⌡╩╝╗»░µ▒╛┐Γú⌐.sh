$ mkdir ~/hgtest
$ cd ~/hgtest
$ hg init
