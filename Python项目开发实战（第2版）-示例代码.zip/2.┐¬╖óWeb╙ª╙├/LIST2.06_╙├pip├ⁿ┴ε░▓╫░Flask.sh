$ pip install -U Flask
