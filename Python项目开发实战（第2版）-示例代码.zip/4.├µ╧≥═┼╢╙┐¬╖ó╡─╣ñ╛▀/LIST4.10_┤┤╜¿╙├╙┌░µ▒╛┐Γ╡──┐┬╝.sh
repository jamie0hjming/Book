$ sudo mkdir /var/lib/hg
$ sudo chown www-data:www-data /var/lib/hg
