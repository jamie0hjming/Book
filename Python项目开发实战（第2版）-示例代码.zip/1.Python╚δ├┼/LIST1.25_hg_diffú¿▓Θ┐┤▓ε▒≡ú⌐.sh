$ hg status
M test.txt

$ hg diff

diff -r 74471564b074 test.txt
--- a/test.txt      Mon Oct 31 18:07:15 2014 +0900
+++ b/test.txt      Mon Oct 31 18:10:45 2014 +0900
@@ -0,0 +1,1 @@
+modify this file
