<template>
  <input type="file" multiple @change="handleFileUpload">
</template>

<script>
import axios from "axios";
export default {
  methods: {
    async handleFileUpload(event) {
      const files = event.target.files;
      let formData = new FormData();
      for (let i = 0; i < files.length; i++) {
        formData.append('files' +  i, files[i]);
      }
      // 可以在这里进行axios文件上传
      // const url = 'http://127.0.0.1:8000'; // 替换成你的后端文件上传接口URL

      axios.post("/api/upload", formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(response => {
        console.log(response.data);
      }).catch(error => {
        console.error(error);
      });
    }
  }
}
</script>