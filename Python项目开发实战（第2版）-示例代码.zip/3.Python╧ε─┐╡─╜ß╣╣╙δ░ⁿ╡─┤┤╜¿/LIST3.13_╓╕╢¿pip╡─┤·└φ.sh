$ pip --proxy=proxy.example.com:1234 install requests
