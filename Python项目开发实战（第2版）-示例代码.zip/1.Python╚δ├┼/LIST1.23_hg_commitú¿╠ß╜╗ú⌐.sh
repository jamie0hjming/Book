$ hg commit

test commit

HG: Enter commit message.  Lines beginning with 'HG:' are removed.
HG: Leave message empty to abort commit.
HG: --
HG: user: bpbook <bpbook@beproud.jp>
HG: branch 'default'
HG: added test.txt
