$ mkdir cgi-bin
$ mv hello.py cgi-bin/
$ chmod u+x cgi-bin/hello.py
$ python -m CGIHTTPServer
Serving HTTP on 0.0.0.0 port 8000 ...
