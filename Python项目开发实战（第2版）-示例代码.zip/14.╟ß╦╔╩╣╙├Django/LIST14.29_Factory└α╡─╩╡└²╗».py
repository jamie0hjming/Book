poll = PollFactory() #=> 与PollFactory.create()效果相同
