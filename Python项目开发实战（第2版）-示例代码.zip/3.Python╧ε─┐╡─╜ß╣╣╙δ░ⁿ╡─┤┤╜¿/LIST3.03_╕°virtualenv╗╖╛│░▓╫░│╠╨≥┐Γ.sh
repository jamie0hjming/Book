(venv)$ pip install requests bottle
(venv)$ pip freeze
bottle==0.12.7
requests==2.4.3
