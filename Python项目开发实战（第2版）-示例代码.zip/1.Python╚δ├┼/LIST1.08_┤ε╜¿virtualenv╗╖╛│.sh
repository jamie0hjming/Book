$ mkdir ~/work
$ cd ~/work
$ virtualenv venv
