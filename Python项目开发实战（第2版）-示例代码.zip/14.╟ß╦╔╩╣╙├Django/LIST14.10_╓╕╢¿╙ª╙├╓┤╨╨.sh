$ python manage.py migrate application
