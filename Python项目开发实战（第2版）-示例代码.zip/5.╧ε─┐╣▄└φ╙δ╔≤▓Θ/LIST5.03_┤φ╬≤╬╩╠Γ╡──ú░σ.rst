现象
====
- 描述该Bug的现象

流程
====
- 描述出现该Bug的操作流程

预期结果
============
- 描述原本应该出现的结果

环境
====
- 描述试验环境

示例
 - OS: Mac OS X 10.10
 - 浏览器：IE11
 - 执行用户：admin
 - 出现Bug的URL：https://staging.example.com/very-critical-feature

相关信息
========
- 描述错误日志、消息Sentry的URL等
