$ pip install -e hg+https://bitbucket.org/shimizukawa/logfilter#egg=logfilter
