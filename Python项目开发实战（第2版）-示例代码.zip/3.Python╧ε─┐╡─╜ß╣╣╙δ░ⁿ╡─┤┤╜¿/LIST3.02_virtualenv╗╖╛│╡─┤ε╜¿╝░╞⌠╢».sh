$ cd /home/bpbook/work
$ virtualenv venv
$ ls -F
venv/
$ source venv/bin/activate
(venv)$
