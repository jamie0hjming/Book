$ sudo service nginx start
