$ nginx -v
nginx version: nginx/1.4.6 (Ubuntu)
