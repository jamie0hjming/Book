class User(object):
    def __init__(self, id, password, nickname, age):
        self.id = id  # 用户ID
        self.password = password  # 密码
        self.nickname = nickname  # 昵称
        self.age = age  # 年龄
