(another-venv)$ deactivate
$ rm -R another-venv
