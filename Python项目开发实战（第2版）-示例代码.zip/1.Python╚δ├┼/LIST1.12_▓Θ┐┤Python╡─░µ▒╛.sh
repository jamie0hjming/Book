$ python3 -V
Python 3.4.0

$ python -V
Python 2.7.6
