$ python -m doctest -v path.py
...
4 tests in 2 items.
4 passed and 0 failed.
Test passed.
