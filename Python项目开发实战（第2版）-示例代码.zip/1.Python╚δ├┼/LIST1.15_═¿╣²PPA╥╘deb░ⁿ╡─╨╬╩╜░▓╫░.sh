$ sudo add-apt-repository ppa:fkrull/deadsnakes
$ sudo apt-get -y update
$ sudo apt-get -y install python2.6
$ python2.6 -V
Python 2.6.9
