# 安装python-dev
$ sudo apt-get -y install python-dev

# 安装pip
$ wget https://bootstrap.pypa.io/get-pip.py
$ sudo python get-pip.py
