with app.test_request_context:
    result = myview()
