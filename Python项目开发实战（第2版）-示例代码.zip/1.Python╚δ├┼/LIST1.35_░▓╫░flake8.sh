$ sudo pip install flake8
