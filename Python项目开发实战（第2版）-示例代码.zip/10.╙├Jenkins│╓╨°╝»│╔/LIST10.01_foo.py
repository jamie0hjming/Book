# -*- coding:utf-8 -*-

def divide(num1, num2):
    """对传值参数做除法的简单函数
    """
    return num1 / num2
