$ sudo apt-get install language-pack-zh-hans
$ sudo update-locale LANG=zh_CN.UTF-8