$ hg clone https://bitbucket.org/beproud/guestbook
$ cd guestbook
$ virtualenv .venv
$ source .venv/bin/activate
(.venv)$ pip install .
(.venv)$ guestbook
 * Running on http://127.0.0.1:5000/
