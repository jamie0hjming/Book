setup(
    name='myapp',
    ...
    install_requires=[
        'securelib>=1.0',
    ],
)
