$ sphinx-quickstart -q -p SW-Project -a BeProud -v 1.0 sw-project
Creating file sw-project/conf.py.
Creating file sw-project/index.rst.
Creating file sw-project/Makefile.
Creating file sw-project/make.bat.

Finished: An initial directory structure has been created.

You should now populate your master file sw-project/index.rst and create other documentation
source files. Use the Makefile to build the docs, like so:
   make builder
where "builder" is one of the supported builders, e.g. html, latex or linkcheck.

$ ls sw-project/
_build  conf.py  index.rst  make.bat  Makefile  _static  _templates
