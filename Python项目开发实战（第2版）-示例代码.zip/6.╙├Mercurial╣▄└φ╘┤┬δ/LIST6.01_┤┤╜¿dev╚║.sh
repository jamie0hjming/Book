$ sudo groupadd dev
