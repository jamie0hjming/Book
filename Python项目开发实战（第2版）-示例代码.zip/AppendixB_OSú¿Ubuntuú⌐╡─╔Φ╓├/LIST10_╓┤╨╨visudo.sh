$ sudo visudo -f /etc/sudoers.d/dev
