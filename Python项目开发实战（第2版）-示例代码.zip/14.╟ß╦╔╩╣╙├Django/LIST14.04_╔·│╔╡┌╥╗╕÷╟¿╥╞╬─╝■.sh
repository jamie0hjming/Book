$ python manage.py makemigrations polls
Migrations for 'polls':
  0001_initial.py:
    - Create model Poll
