$ pip install https://bitbucket.org/shimizukawa/logfilter/get/logfilter-0.9.2.zip
