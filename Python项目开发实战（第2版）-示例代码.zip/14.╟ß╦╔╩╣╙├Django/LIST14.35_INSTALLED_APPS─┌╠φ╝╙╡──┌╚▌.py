INSTALLED_APPS = (
    .
    .
    'django.contrib.staticfiles'  # 在‘debug_toolbar’之前设置
    .
    .
    'debug_toolbar' # <- 添加
)
