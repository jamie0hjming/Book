$ python setup.py sdist
running sdist
running egg_info
writing requirements to guestbook.egg-info/requires.txt
writing guestbook.egg-info/PKG-INFO
writing top-level names to guestbook.egg-info/top_level.txt
writing dependency_links to guestbook.egg-info/dependency_links.txt
reading manifest file 'guestbook.egg-info/SOURCES.txt'
reading manifest template 'MANIFEST.in'
writing manifest file 'guestbook.egg-info/SOURCES.txt'
running check
creating guestbook-1.0.0
-（中间省略）-
making hard links in guestbook-1.0.0...
hard linking LICENSE.txt -> guestbook-1.0.0
-（中间省略）-
Creating tar archive
removing 'guestbook-1.0.0' (and everything under it)

$ ls dist/
guestbook-1.0.0.tar.gz
