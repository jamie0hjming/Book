$ sudo chgrp -R dev /var/hg/testrepo/.hg
