$ sudo service nginx restart
