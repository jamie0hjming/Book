$ pip install httpbin
