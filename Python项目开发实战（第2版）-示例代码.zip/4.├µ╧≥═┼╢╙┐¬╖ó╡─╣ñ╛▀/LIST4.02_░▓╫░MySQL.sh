$ sudo apt-get install -y mysql-server mysql-client
