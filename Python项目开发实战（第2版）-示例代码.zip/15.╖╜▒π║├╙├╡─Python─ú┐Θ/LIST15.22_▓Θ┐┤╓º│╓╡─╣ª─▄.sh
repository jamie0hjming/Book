running build_ext
--------------------------------------------------------------------
PIL SETUP SUMMARY
--------------------------------------------------------------------
version      Pillow 2.6.1
platform     linux2 2.7.6 (default, Mar 22 2014, 22:59:56)
             [GCC 4.8.2]
--------------------------------------------------------------------
*** TKINTER support not available
--- JPEG support available
--- OPENJPEG (JPEG2000) support available (2.1.3)
--- ZLIB (PNG/ZIP) support available
--- LIBTIFF support available
--- FREETYPE2 support available
--- LITTLECMS2 support available
--- WEBP support available
--- WEBPMUX support available
--------------------------------------------------------------------
To check the build, run the selftest.py script.
