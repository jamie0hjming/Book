$ python manage.py startapp polls
